describe('News Page Tests', () => {
  
  beforeEach(() => {
    cy.viewport(1920, 911); // Set to your testing resolution
    cy.visit('http://127.0.0.1:5500/Version2/news.html'); // URL to the news page
  });

  it('should load the page with main elements visible', () => {
    cy.get('.zoom-control').should('be.visible');
    cy.get('.header-container').should('be.visible');
    cy.get('.content-container').should('be.visible');
    cy.get('#suggestion-box').should('be.visible');
    cy.get('#most-requested').should('be.visible');
  });

  it('should display the correct category in the header based on localStorage', () => {
    cy.window().then((win) => {
      win.localStorage.setItem('selectedCategory', 'Technology');
    });
    cy.reload();
    cy.get('#categoryName').should('contain', 'Technology');
  });

  it('should zoom the content when the zoom slider is adjusted', () => {
    cy.get('#zoomSlider')
      .invoke('val', 1.25)
      .trigger('input')
      .wait(300);
    cy.get('#mainContent').then($mainContent => {
      const transformValue = $mainContent.css('transform');
      cy.log('Transform Value:', transformValue); // Log the actual transform value
      expect(transformValue).to.equal('matrix(1.25, 0, 0, 1.25, 0, 0)');
    });
  });

  it('should toggle dark mode', () => {
    cy.get('body').should('not.have.class', 'dark-mode');
    cy.get('#themeToggle').click();
    cy.get('body').should('have.class', 'dark-mode');
    cy.get('#themeToggle').click();
    cy.get('body').should('not.have.class', 'dark-mode');
  });

  it('should add a new suggested topic and display it in Most Requested Topics', () => {
    cy.get('#suggestionInput').type('Environment');
    cy.contains('button', 'Submit').click();
    cy.get('#requestedTopicsList').should('contain', 'Environment');
  });

  it('should display articles dynamically loaded based on category', () => {
    cy.get('#article-list .article').should('have.length.greaterThan', 0);
  });

  // Check the position of the Back to Home button
  it('should check the position of the Back to Home button', () => {
    cy.get('.back-home-btn').should('be.visible').then(($btn) => {
      const rect = $btn[0].getBoundingClientRect();
      cy.log('Button Position - Top:', rect.top);
      cy.log('Button Position - Left:', rect.left);

      // Assert position values to match Version 1 layout
      expect(rect.top).to.be.closeTo(20, 1);          // Expected top position with small tolerance
      expect(rect.left).to.be.closeTo(1403.5625, 1);  // Expected left position with small tolerance
    });
  });

  // Check the size of the Read More button
  it('should check the size of the Read More button', () => {
    cy.get('.article button').first().should('be.visible').then(($btn) => {
      const rect = $btn[0].getBoundingClientRect();
      cy.log('Button Width:', rect.width);
      cy.log('Button Height:', rect.height);

      // Expected size values for Version 1 with small tolerance
      expect(rect.width).to.be.closeTo(99.265625, 1); // Expected width with small tolerance
      expect(rect.height).to.be.closeTo(36, 1);       // Expected height with small tolerance
    });
  });

  // Check the orientation of all article images
  it('should check the orientation of all article images', () => {
    cy.get('.article img').each(($img) => {
      // Check if the image has no transformation applied (no 180-degree rotation)
      cy.wrap($img).should('have.css', 'transform', 'none');
    });
  });

  it('should navigate to article.html with correct content when Read More button is clicked', () => {
    // Click the "Read More" button on the first article
    cy.get('.article button').contains('Read More').first().click();

    // Verify that the URL includes article.html
    cy.url().should('include', '/article.html');

    // Access window localStorage to retrieve stored values for validation
    cy.window().then((win) => {
      const expectedTitle = win.localStorage.getItem('articleTitle');
      const expectedContent = win.localStorage.getItem('articleContent');
      const expectedImage = win.localStorage.getItem('articleImage');

      // Assert that these values are not null or undefined
      expect(expectedTitle).to.exist;
      expect(expectedContent).to.exist;
      expect(expectedImage).to.exist;

      // Verify that the article page displays the correct title, content, and image
      cy.get('#articleTitle').should('have.text', expectedTitle);
      cy.get('#articleContent').should('contain.text', expectedContent);
      cy.get('#articleImage').should('have.attr', 'src', expectedImage);
    });
  });
  
});
  