describe('Check elements on local HTML file', () => {
    beforeEach(() => {
      cy.viewport(1920, 911);
      // Visit the URL before each test
      cy.visit('http://127.0.0.1:5500/Version1/article.html');
    });
  
    it('should verify mainContent ID is present in the page', () => {
      // Check if an element with ID 'mainContent' exists
      cy.get('#mainContent').should('exist');
    });
    
    it('should load the page with main elements visible', () => {
      cy.get('.zoom-control').should('be.visible');
      cy.get('.header-container').should('be.visible');
      cy.get('.article-card-container').should('be.visible');
      
    });
  
    it('should display article title, content, and image', () => {
      cy.get('#articleTitle').should('contain', 'AI Revolution in 2024');
      cy.get('#articleContent').should('contain', 'Artificial Intelligence has seen unprecedented growth');
      cy.get('#articleImage').should('have.attr', 'src').and('include', 'images/ai_revolution.jpg');
    });
  
    it('should zoom the content when the zoom slider is adjusted', () => {
      cy.get('#zoomSlider')
      .invoke('val', 1.25)
      .trigger('input')
      .wait(300);
      
      cy.get('#mainContent').should('have.css', 'transform', 'matrix(1.25, 0, 0, 1.25, 0, 0)');
    });
  
    it('should toggle dark mode', () => {
      cy.get('body').should('not.have.class', 'dark-mode');
      cy.get('#themeToggle').click();
      cy.get('body').should('have.class', 'dark-mode');
      cy.get('#themeToggle').click();
      cy.get('body').should('not.have.class', 'dark-mode');
    });
  
    it('should add a new comment and display it', () => {
      cy.get('#commentBox').type('Great article on AI!');
      cy.contains('button', 'Add Comment').click();
      cy.get('#commentSection').should('contain', 'Great article on AI!');
      cy.get('#commentSection').should('be.visible');
    });

     // Check the orientation of the article image
  it('should check the orientation of the article image', () => {
    cy.get('#articleImage').should('be.visible').then(($img) => {
      // Confirm no transform applied in Version 1
      cy.wrap($img).should('have.css', 'transform', 'none');
    });
  });

  // Check the position of the Add Comment button
  it('should check the position of the Add Comment button', () => {
    cy.get('.add-comment-container button').should('be.visible').then(($btn) => {
      const rect = $btn[0].getBoundingClientRect();
  
      cy.log('Actual Top Position:', rect.top);
      cy.log('Actual Left Position:', rect.left);
  
      // Use the observed top and left values from the Cypress test log
      expect(rect.top).to.be.closeTo(712.265625, 1);  // Adjusted top position
      expect(rect.left).to.be.closeTo(903.25, 1);      // Original left position
    });
  });

  // Check the size of the Add Comment button
  it('should check the size of the Add Comment button', () => {
    cy.get('.add-comment-container button').should('be.visible').then(($btn) => {
      const rect = $btn[0].getBoundingClientRect();
      cy.log('Button Width:', rect.width);
      cy.log('Button Height:', rect.height);

      // Expected size values for Version 1 with small tolerance
      expect(rect.width).to.be.closeTo(113.484375, 1); // Expected width with small tolerance
      expect(rect.height).to.be.closeTo(40, 1);       // Expected height with small tolerance
    });
  });

  it('should navigate to news.html when the Go Back button is clicked', () => {
    // Click the Go Back button
    cy.get('.back-news-btn').contains('Go Back').click();

    // Verify that the URL navigates to news.html as expected in Version 1
    cy.url().should('include', '/news.html');
  });
  
  });
  