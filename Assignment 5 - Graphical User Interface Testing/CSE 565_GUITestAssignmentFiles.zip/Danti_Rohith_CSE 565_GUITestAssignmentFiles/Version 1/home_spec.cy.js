describe('Check elements on local HTML file', () => {
  beforeEach(() => {
    cy.viewport(1920, 911);
    // Visit the URL before each test
    cy.visit('http://127.0.0.1:5500/Version1/index.html');
  });
  
  it('should load the page with main elements visible', () => {
    cy.get('.controls').should('be.visible');
    cy.get('.container').should('be.visible');
    cy.get('header h1').contains('Welcome to the News App').should('be.visible');
  });

  it('should toggle dark mode', () => {
    // Ensure the initial state of the theme is not dark mode
    cy.get('body').should('not.have.class', 'dark-mode');
  
    // Toggle dark mode on by clicking the checkbox
    cy.get('#themeToggle').click();
    cy.get('body').should('have.class', 'dark-mode');
  
    // Toggle dark mode off by clicking the checkbox again
    cy.get('#themeToggle').click();
    cy.get('body').should('not.have.class', 'dark-mode');
  });
  

  it('should adjust zoom level with the slider', () => {
    cy.get('#zoomSlider').invoke('val', 1.25).trigger('input');
    cy.get('#mainContent').should('have.css', 'transform', 'matrix(1.25, 0, 0, 1.25, 0, 0)');
  });

  it('should display no results message when search fails', () => {
    cy.get('#searchBox').type('Nonexistent Topic');
    cy.contains('button', 'Search').click();
    cy.get('#noResultsMessage').should('be.visible').and('contain', 'No news found');
  });

  it('should navigate to article page when a valid search term is entered', () => {
    cy.get('#searchBox').type('AI');
    cy.contains('button', 'Search').click();
    cy.url().should('include', '/article.html');
    // Validate localStorage has the correct article data
    cy.window().then((win) => {
      expect(win.localStorage.getItem('articleTitle')).to.eq('AI Revolution in 2024');
    });
  });

  it('should prefill search box with suggestion tag click', () => {
    cy.contains('.suggestion-tag', 'Mars').click();
    cy.get('#searchBox').should('have.value', 'Mars');
  });


  

  it('should clear category selection in localStorage if none selected', () => {
    cy.get('#explore').click();
    cy.url().should('include', '/news.html');
    cy.window().then((win) => {
      expect(win.localStorage.getItem('selectedCategory')).to.be.null;
    });
  });

  // New Test: Check the Position of the Search Button
  it('should check the position of the Search button', () => {
    cy.get('button[onclick="searchNews()"]').should('be.visible').then(($btn) => {
      const rect = $btn[0].getBoundingClientRect();
      cy.log('Button Position - Top:', rect.top);
      cy.log('Button Position - Left:', rect.left);
      expect(rect.top).to.be.closeTo(530.47, 1); // Adjusted for Version 1
      expect(rect.left).to.be.closeTo(1021.59, 1);
    });
  });

  // New Test: Check the Size of the Search Button
  it('should check the size of the Search button', () => {
    cy.get('button[onclick="searchNews()"]').should('be.visible').then(($btn) => {
      const rect = $btn[0].getBoundingClientRect();
      cy.log('Button Width:', rect.width);
      cy.log('Button Height:', rect.height);
      expect(rect.width).to.be.closeTo(58.25, 1); // Adjust based on Version 1 dimensions
      expect(rect.height).to.be.closeTo(21, 1);
    });
  });
  
  it('should check the orientation of the banner image', () => {
    cy.get('img.banner-image').should('be.visible').then(($img) => {
      const naturalWidth = $img[0].naturalWidth;
      const naturalHeight = $img[0].naturalHeight;
      
      expect(naturalWidth).to.be.greaterThan(naturalHeight); 

      // If mirroring was handled by CSS transform, we could test with:
      cy.get('img.banner-image').should('have.css', 'transform', 'none'); 
    });
  });
    
});
  
  